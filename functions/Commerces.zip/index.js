const shops = require('./data.json');

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const findShops = async function findShops(event) {
  if (event.id) {
    const shop = shops.filter((b) => (b.recordid === event.id));
    if (shop.length > 0) return shop[0];
  }

  let res = shops;
  console.log(res.length);
  if (event.category && event.category.length > 0) {
    res = res.filter((b) => b.fields.type_de_commerce.indexOf(event.category) !== -1);
  }
  console.log(res.length);
  if (event.arrondissement && event.arrondissement.length > 0 && event.arrondissement !== 'any') {
    res = res.filter((b) => (b.fields.code_postal === event.arrondissement));
  }
  console.log(res.length);
  if (event.service && event.service.length > 0 && event.service !== 'any') {
    res = res.filter((b) => (b.fields.services.indexOf(event.service) !== -1));
  }
  return shuffle(res).slice(0, 5);
};
exports.handler = async (event) => findShops(event);
